## MLFlow

## Notebooks

Os notebooks do projeto estão presentes na diretoria `notebooks`.

Dentro desta diretoria temos 2 outras diretorias, `mlflow` e `serve`:

* `mlflow`: notebooks que vamos usar para explorar o mlflow
* `serve`: notebook auxiliar para testar o mlflow serve e a fastapi app com o modelo. As respetivas secções de `mlflow serve` e `fastapi` só podem ser corridas quando o `mlflow serve` e `fastapi` estiverem a correr respetivamente.